package com.example.qrcodeexample.qrcodedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QrcodedemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
